#Importar documento csv
import csv
totales=[]
paises_exportacion=[]
exportacion=[]
eleccion =[]

lista =[]

with open("synergy_logistics_database.csv","r") as archivo:
  lector = csv.reader(archivo)

  for linea in lector: #para trabajar con listas
    lista.append(linea)

  print("\tBIENVENIDOS")
  print("\n¿Qué desea ver?")
  print("\n1.Rutas de exportación\n2.Rutas importación\n3.Medios de transporte para exportaciones\n4.Medios de transporte para importaciones\n5.Valor total de importaciones y exportaciones")

  eleccion=input("\n\tEscriba el número: ")

  
  #PROMEDIO GENERAL---------------------------------
  for valor in lista:
    if valor[9] == "total_value":
      continue 
    totales.append(int(valor[9]))
  promedio=[sum(totales)/len(totales)]
    #De aquí obtuve el promedio para comparar el valor, al menos debe ser mayor para ser considerado en el conteo. Así se tomará en cuenta su valor y la frecuencia, una manera rápida y sencilla. 
  archivo.seek(0) #se agrega para volver a utilizar la lista con los datos. 

  #EXPORTACIONES E IMPORTACIONES-----------------------------
  def rutas_uno(direccion):
    contador =0
    rutas_enlista=[]
    rutas_exportacion=[]

    #filtrar lista: solo considerando exportaciones/importaciones, los índices de origen y destino y que además no se repitan entre ellos.
    for ruta in lista:
      if ruta[1] == direccion and ruta[9] > "11318812.86":
        ruta_actual = [ruta[2],ruta[3]] 
        
        if ruta_actual not in rutas_enlista:
          for movimiento in lista:
            if ruta_actual == [movimiento[2],movimiento[3]] and movimiento[1]== direccion:
              contador += 1#para reconocer las frecuencias.
        
          rutas_enlista.append(ruta_actual) 
          rutas_exportacion.append([ruta[2], ruta[3], contador]) #Origen, Destino, Frecuencia
          contador = 0 #se reinicia el contador, para que pase a la siguiente iteración

    rutas_exportacion.sort(reverse=True,key = lambda x:x[2])
    rutas_finales = rutas_exportacion[0:10] #para solo obtener 10.
    print("Origen/  Destino/  Frecuencia")

    for i in range(len(rutas_finales)):
      print("~",rutas_finales[i][0], "-", rutas_finales[i][1], "\t=", rutas_finales[i][2])

    #----------------------------------------------------------

   #Se hizo una función para poder repetir el proceso pero usando Imports como argumento.
   
  archivo.seek(0)

  #TRANSPORTE DE ACUERDO A SU VALOR -----------------
  def transporte_dos(transporte_modalidad,direccion):
    contador =0
    suma_score=0 #Para obtener promedio
    transporte_enlista=[]
    promedio_transporte=[]
  
      #filtrar lista: solo considerando el medio de transporte.
    for transporte in lista:
      if transporte[7] == transporte_modalidad and transporte[1] == direccion:
        transporte_actual = [transporte[7]] 
        #El procedimiento es muy parecido, solo ahora considerando el transporte en el ínidice 7
        if transporte_actual not in transporte_enlista:
          for modalidad in lista:
            if transporte_actual == [modalidad[7]] and modalidad[1] == direccion:
              contador += 1
              suma_score+= int(modalidad[9])
              #para reconocer las frecuencias y la sumatoria
          transporte_enlista.append(transporte_actual)

          promedio = suma_score / contador
          promedio_transporte.append([transporte[7],contador,promedio])
          contador =0
          suma_score = 0
          #Se representa Transporte + Frecuencia + Promedio
    
    print("Modalidad/Frecuencia")
    #Ordenar print
    for i in range(len(promedio_transporte)):
      print("~",promedio_transporte[i][0], " --> ", promedio_transporte[i][1], "\t ~ promedio: ", promedio_transporte[i][2])

  """"
  transporte_dos("Sea","Imports")
  transporte_dos("Air","Imports")
  transporte_dos("Rail","Imports")
  transporte_dos("Road","Imports")
  """
  
  #80% DEL VALOR + OTROS FILTROS----------------------
  archivo.seek(0)
  def filtros_tres (numero):
    valor_enlista=[]
    suma_score=0
    contador =0
    promedio_ochenta=[]

    #Se hará un procedimiento parecido, nuevamente se obtienen las frecuencias y la sumatoria, pero utilizando el valor y haciendo caso omiso a la dirección
    for valor in lista:
      if valor[9] == "total_value":
        continue
      valor_actual = [valor[2],valor[3]] 


      if valor_actual not in valor_enlista:
        for ochenta in lista:
          if valor_actual == [ochenta[2], ochenta[3]]:
            contador += 1
            suma_score+=int(ochenta[9])
            #para reconocer las frecuencias y la sumatoria
       
        valor_enlista.append(valor_actual)
        promedio_sumascore= suma_score / contador
        porcentaje= suma_score*100/sum(totales)
          
        promedio_ochenta.append([valor[2],valor[3],valor[7], contador,suma_score,promedio_sumascore, porcentaje,valor[1]])
        contador =0
        suma_score = 0
        #Se representa Orien+Destino+Transporte+Frecuencia+Sumatoria+Promedio+Porcentaje+Direccion
    
    promedio_ochenta.sort(reverse=True,key = lambda x:x[numero])

    #numero = 3 --> por repeticiones
    #numero = 4 --> por suma
    #numero = 5 --> por promedio
    #numero = 6 --> por porcentaje

    promedio_enlista=[]
    promedios_ordenados=[]
    suma=0

    for promedio in promedio_ochenta:
      promedio_actual = promedio[0],promedio[1]
      
      if promedio_actual not in promedio_enlista:
        while suma < 80:
          for i in promedio_ochenta:
            suma += i[6]
            promedios_ordenados.append(suma)

    promedio_enlista.append(promedio_actual)
    
    
    print("\nOrigen/Destino/Direccion/Transporte/Frecuencia/Sumatoria/Promedio/Porcentaje\n")
    for i in range(len(promedio_ochenta)):
      print("~",promedio_ochenta[i][0], "-", promedio_ochenta[i][1], "~",promedio_ochenta[i][7],"|",promedio_ochenta[i][2],"|",promedio_ochenta[i][3],"|",promedio_ochenta[i][4],"|",promedio_ochenta[i][5],"|", promedio_ochenta[i][6])
    print()
    #Para conocer el 80%, se me dificultó agregarlos en una sola lista, así que solo conté los que representan el 80. Perdón :c.

    #for j in range(len(promedios_ordenados)):
      #print("~", promedios_ordenados[j])

  
  #----------------------------------
  #MENÚ DE INICIO


  if eleccion == "1":
    print("\t\n10 RUTAS DE EXPORTACIÓN MÁS DEMANDADAS\n")
    rutas_uno("Exports")
  
  elif eleccion == "2":
    print("\t\n10 RUTAS DE IMPORTACIÓN MÁS DEMANDADAS\n")
    rutas_uno("Imports")

  elif eleccion == "3":
    print("\t\nMEDIOS DE TRANSPORTE EXPORTACIONES\n")
    transporte_dos("Sea","Exports")
    transporte_dos("Air","Exports")
    transporte_dos("Rail","Exports")
    transporte_dos("Road","Exports")
  
  elif eleccion == "4":
    print("\t\nMEDIOS DE TRANSPORTE IMPORTACIONES\n")
    transporte_dos("Sea","Imports")
    transporte_dos("Air","Imports")
    transporte_dos("Rail","Imports")
    transporte_dos("Road","Imports")

  elif eleccion == "5":
    print ("\t\nVALORES TOTALES\n")
    print("¿Cómo desea filtrar la información?\n")
    print(" 1. Por frecuencias.\n 2. Por sumatoria\n 3.Por promedio\n 4. Por porcentaje\n")

    eleccion_valor = input("Escriba el número: ")

    if eleccion_valor == "1":
      print("\t\nORDENADOS POR FRECUENCIAS\n")
      filtros_tres(3)
    
    elif eleccion_valor == "2":
      print("\t\nORDENADOS POR SUMATORIAS\n")
      filtros_tres(4)
    
    elif eleccion_valor == "3":
      print("\t\nORDENADOS POR PROMEDIO\n")
      filtros_tres(5)

    elif eleccion_valor == "4":
      print("\t\nEl 80% está representado desde China-México Exports hasta Canada - USA Exports.\n")
      print("\t\nORDENADOS POR PORCENTAJE\n")
      filtros_tres(6)
    else:
     
      print("Por favor, elija el número correspondiente")

  else:
    print("Por favor, elija un número en el rango adecuado.")

    

    

 
  
